package mc.codegen

/**
 * @author nhphung
 */
case class IllegalOperandException(s:String) extends Exception
case class IllegalRuntimeException(s:String) extends Exception